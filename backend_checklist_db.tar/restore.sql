--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.4
-- Dumped by pg_dump version 14.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE backend_checklist;
--
-- Name: backend_checklist; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE backend_checklist WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Indonesia.1252';


ALTER DATABASE backend_checklist OWNER TO postgres;

\connect backend_checklist

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: detail_checklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detail_checklist (
    checklist_item_id bigint NOT NULL,
    checklist_item_name character varying(500),
    checklist_id integer,
    status_checked boolean
);


ALTER TABLE public.detail_checklist OWNER TO postgres;

--
-- Name: body_checklist_checklist_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.body_checklist_checklist_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.body_checklist_checklist_item_id_seq OWNER TO postgres;

--
-- Name: body_checklist_checklist_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.body_checklist_checklist_item_id_seq OWNED BY public.detail_checklist.checklist_item_id;


--
-- Name: header_checklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.header_checklist (
    checklist_id bigint NOT NULL,
    checklist_name character varying(500)
);


ALTER TABLE public.header_checklist OWNER TO postgres;

--
-- Name: header_checklist_checklist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.header_checklist_checklist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.header_checklist_checklist_id_seq OWNER TO postgres;

--
-- Name: header_checklist_checklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.header_checklist_checklist_id_seq OWNED BY public.header_checklist.checklist_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(500),
    password character varying(500),
    token text,
    email character varying(250)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: detail_checklist checklist_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_checklist ALTER COLUMN checklist_item_id SET DEFAULT nextval('public.body_checklist_checklist_item_id_seq'::regclass);


--
-- Name: header_checklist checklist_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.header_checklist ALTER COLUMN checklist_id SET DEFAULT nextval('public.header_checklist_checklist_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: detail_checklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3327.dat

--
-- Data for Name: header_checklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3324.dat

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3323.dat

--
-- Name: body_checklist_checklist_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.body_checklist_checklist_item_id_seq', 5, true);


--
-- Name: header_checklist_checklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.header_checklist_checklist_id_seq', 5, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: detail_checklist detail_checklist_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_checklist
    ADD CONSTRAINT detail_checklist_pk PRIMARY KEY (checklist_item_id);


--
-- Name: header_checklist header_checklist_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.header_checklist
    ADD CONSTRAINT header_checklist_pk PRIMARY KEY (checklist_id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

